// patch_appjs_escapehelpers_fix.mjs
// Fixes a broken escapeHtml() helper that was inserted with literal "\n" tokens (causing SyntaxError).
// Usage: node patch_appjs_escapehelpers_fix.mjs

import fs from "fs";

const candidates = [
  "public/app.js",
  "./public/app.js",
  "app.js",          // fallback (some dev setups)
];

function readFirstExisting(paths){
  for (const p of paths){
    if (fs.existsSync(p)) return { path: p, text: fs.readFileSync(p, "utf8") };
  }
  throw new Error("Could not find app.js. Looked in: " + paths.join(", "));
}

const { path, text } = readFirstExisting(candidates);

const pattern = /\/\/\s*-+\s*Escaping helpers\s*-+\s*\nfunction escapeHtml\(s\)\s*\{[\s\S]*?function escapeAttr\(s\)\s*\{[\s\S]*?\n\}/m;

if (!pattern.test(text)) {
  throw new Error("Escaping helpers block not found. No changes made.");
}

const replacement =
`// -------------------- Escaping helpers --------------------
function escapeHtml(s) {
  return String(s || "").replace(/[&<>"']/g, (c) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;",
  }[c]));
}

function escapeAttr(s) {
  return String(s || "").replace(/"/g, "&quot;");
}`;

const out = text.replace(pattern, replacement);

fs.writeFileSync(path, out, "utf8");
console.log(`[escapehelpers_fix] Patched: ${path}`);
