APPJS ESCAPE HELPERS FIX (SyntaxError: Invalid or unexpected token)

This patch fixes a broken escapeHtml() helper block that was written into public/app.js with literal \n tokens,
which breaks parsing and causes the whole UI (tabs/buttons) to stop working.

Install:
  cd ~/Desktop/projects/pdfrealm
  unzip -o pdfrealm_appjs_escapehelpers_fix.zip
  node patch_appjs_escapehelpers_fix.mjs

Verify:
  node --check public/app.js

Restart:
  node server.js
