# PDFRealm Encrypted Container Format (PVR1)

This document describes the PDFRealm encrypted container format used by the in‑app “Encrypted Containers” tool.

## Goals

- Users can decrypt containers **without** PDFRealm (offline, local-only).
- The format is **versioned**, transparent, and based on standard cryptography.

## Crypto

- **KDF**: PBKDF2 with SHA‑256
  - `iterations`: default 250,000 (stored in header)
  - `salt`: random 16 bytes (stored in header as base64)
- **Encryption**: AES‑256‑GCM (per file)
  - `iv`: random 12 bytes (stored per file as base64)
  - **AAD**: UTF‑8 bytes of JSON string containing `{ name, type, size, mtime }`
  - GCM tag: 128-bit, appended to ciphertext by WebCrypto (included in `length`)

## Binary Layout

All integers are little‑endian.

```
0..3    ASCII magic "PVR1"
4..7    uint32 header_len
8..(8+header_len-1)    UTF‑8 JSON header
(8+header_len)..EOF    concatenated ciphertext blobs for each file (GCM-tag included per blob)
```

## Header JSON

Example (abridged):

```json
{
  "v": 1,
  "kdf": { "name": "PBKDF2", "hash": "SHA-256", "iterations": 250000, "salt": "..." },
  "enc": { "name": "AES-GCM" },
  "createdAt": "2025-12-31T00:00:00.000Z",
  "files": [
    {
      "name": "document.pdf",
      "type": "application/pdf",
      "size": 12345,
      "mtime": 1735600000000,
      "iv": "...",
      "aad": "{\"name\":\"document.pdf\",\"type\":\"application/pdf\",\"size\":12345,\"mtime\":1735600000000}",
      "offset": 0,
      "length": 12461
    }
  ]
}
```

### `files[]` fields

- `name`: original filename
- `type`: MIME type (optional)
- `size`: original byte size (informational)
- `mtime`: last-modified timestamp (ms)
- `iv`: base64 IV used for AES-GCM
- `aad`: AAD JSON string (must match for decrypt)
- `offset`: byte offset into the ciphertext region
- `length`: ciphertext+tag length in bytes (slice length)

## Compatibility Note

Browsers can decrypt by passing the full ciphertext slice (including tag) to WebCrypto.
Node.js must split the last 16 bytes as the GCM auth tag when using `crypto.createDecipheriv('aes-256-gcm', ...)`.