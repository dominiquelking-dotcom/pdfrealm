# PDFRealm Offline Container Unlocker (Bundle)

This bundle decrypts PDFRealm `.pvr` containers locally, without PDFRealm.

## Recommended (fastest, least issues)
Run a small local web server (avoids browser restrictions on `file://`) and open the unlocker.

### Windows
Double-click: `start_windows.bat`

### macOS
Right-click `start_mac.command` → Open (first run will prompt)

### Linux
Run: `./start_linux.sh`

Then your browser opens:
http://localhost:8088/pdfrealm_container_unlocker.html

## Manual fallback
Run in this folder:

- `python3 -m http.server 8088`

Then open:
http://localhost:8088/pdfrealm_container_unlocker.html

## Security assurances
- No uploads required.
- Password never leaves your device.
- Decryption uses PBKDF2-SHA256 + AES-256-GCM (see `spec.md`).