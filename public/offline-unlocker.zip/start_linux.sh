#!/bin/bash
set -e
cd "$(dirname "$0")"
python3 -m http.server 8088 &
SERVER_PID=$!
sleep 1
xdg-open "http://localhost:8088/pdfrealm_container_unlocker.html" >/dev/null 2>&1 || true
wait $SERVER_PID
